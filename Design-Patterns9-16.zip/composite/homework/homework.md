---
title: Composite模式课后作业
---

### 习题11-1

请思考一下，除了文件系统以外，还有哪些地方使用了Composite模式。

#### 答案

HTML中的列表和表格等都可以用Composite模式表示。

---

### 习题11-2

请为示例程序中的Entry类（子类）的 实例增加一个获取完整路径的功能。例如，我们需要从File的实例中获取如下的完整路径。

`		“/root/usr/yuki/Composite.java”`

这时，应该修改示例程序中的哪些类呢？应该怎么修改呢？

#### 答案

代码见包``composite.homework`中