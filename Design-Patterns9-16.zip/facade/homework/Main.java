package facade.homework;

import facade.homework.pagemaker.PageMaker;

public class Main {
    public static void main(String[] args) {
        PageMaker.makeLinkPage("E:\\Java\\Design-Patterns\\src\\facade\\homework\\linkpage.html");
    }
}
