package strategy.homework.A4;

import java.lang.Comparable;

public interface Sorter {
    public abstract void sort(Comparable[] data);
}
