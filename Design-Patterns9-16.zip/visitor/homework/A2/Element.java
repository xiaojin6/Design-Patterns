package visitor.homework.A2;

public interface Element {
    public abstract void accept(Visitor v);
}
