package visitor.homework.A3;

public interface Element {
    public abstract void accept(Visitor v);
}
