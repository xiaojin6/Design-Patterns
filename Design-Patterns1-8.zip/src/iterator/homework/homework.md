---
title: Iterator模式课后作业
---

### 习题1-1

#### 答案

见包`iterator.homework`中