package adapter;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Print p = new PrintBanner("Hello");
		p.printWeak();
		p.printStrong();
	}

}
