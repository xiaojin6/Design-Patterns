package factory.homework.framework;

public abstract class Product {
    public abstract void use();
}
