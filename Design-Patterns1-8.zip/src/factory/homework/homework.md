---
title: Factory Method模式课后作业
---

### 习题4-1

#### 答案

这是因为想让`idcard`包外的类无法new出`IDCard`类的实例。这样就可以使外部必须通过`IDCardFactory`来生成`IDCard`的实例。

###  习题4-2

请修改示例程序，为`IDCard`类添加卡的编号，并在`IDCardFactory`类中保存编号与所有者之间的对应表。

#### 答案

具体答案见包`factory.homework`中

### 习题4-3

#### 答案

因为Java中无法定义abstract的构造函数。

