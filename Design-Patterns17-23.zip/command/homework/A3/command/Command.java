package command.homework.A3.command;

public interface Command {
    public abstract void execute();
}
