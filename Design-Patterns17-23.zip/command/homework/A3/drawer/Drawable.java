package command.homework.A3.drawer;

public interface Drawable {
    public abstract void draw(int x, int y);
}
