---
title: Command模式课后习题
---

### 习题22-1

请在示例程序中增加“设置颜色”的功能。就像手中握有多指不同颜色的笔一样，设置了新的颜色后，当拖动鼠标时，会画出新颜色的点。

tips：新建一个`ColorCommand`类，用来表示设置颜色命令。

#### 答案

详细答案见包`command.homework.A1`

---

### 习题22-2

请在示例程序中增加撤销功能，它的作用时”删除上一次画的点“。

#### 答案

详细答案见包`command.homework.A2`

---

### 习题22-3

请修改示例程序，在Main类中不适用`MouseMotionListener`接口和`WindowListener`接口，而是使用`MonsuMotionAdapter`类和`WindowApater`类。

#### 答案

详细答案见包`command.homework.A3`