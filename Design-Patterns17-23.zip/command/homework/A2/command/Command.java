package command.homework.A2.command;

public interface Command {
    public abstract void execute();
}
