package command.homework.A2.drawer;

public interface Drawable {
    public abstract void draw(int x, int y);
}
