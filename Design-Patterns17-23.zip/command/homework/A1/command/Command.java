package command.homework.A1.command;

public interface Command {
    public abstract void execute();
}
