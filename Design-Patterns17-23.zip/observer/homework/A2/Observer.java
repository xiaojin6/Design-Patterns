package observer.homework.A2;

public interface Observer {
    public abstract void update(NumberGenerator generator);
}
