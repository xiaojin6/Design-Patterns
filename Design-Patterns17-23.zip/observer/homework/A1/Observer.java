package observer.homework.A1;

public interface Observer {
    public abstract void update(NumberGenerator generator);
}
